# Voxel Frontier

A browser-playable 3D voxel sandbox prototype.

## Run
Open `index.html` in a modern browser with an internet connection on first load. The Three.js engine is loaded from jsDelivr CDN.

## Controls
- Desktop: WASD / arrow keys to move, Space to jump, mouse drag to look.
- Left-click breaks a block; right-click places the selected block.
- Keys 1–6 select blocks. E opens inventory. F changes camera.
- Mobile/tablet: use on-screen directional controls and action buttons; drag the world to look.

## Included
- Procedural terrain, trees, block selection, breaking and placing
- First-person and third-person camera
- Creative/Survival toggle, health and hunger counters
- Inventory and basic wood-to-planks crafting
- Local save/load, simple clouds and lighting

## Limitations
This is a playable starter build, not a complete Minecraft-scale game. Advanced NPCs, enemy AI, boss fights, quests, full crafting trees, extensive biome-specific systems, and robust collision/terrain streaming still need further development. Browser local saves are stored only on the same device/browser. For best results, host the folder on a static HTTPS host.
